package com.example.adminhomepage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ComplaintsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints_page);
    }
}