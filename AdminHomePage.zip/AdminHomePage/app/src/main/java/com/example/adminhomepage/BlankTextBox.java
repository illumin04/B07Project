package com.example.adminhomepage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BlankTextBox extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blank_text_box);
    }
}